********************************************************************************
*	REPLICATION OF TIME SERIES FIGURES FOR "Double Selection in Causal Inference"
*	by
*	Alemán, Christian
*	Busch, Christopher
*	Santaeulàlia-Llopis, Raül
*	Surovtseva, Tetyana
*	(c) October 2026
*	contact: christopher.busch@econ.lmu.de
*
*	DS_APP_GEN_TIMESERIES.do
*	output: figures of time series for raw and normalized mean wages
*	(Figures 5(a), 6(a), 6(b), 7(a))
*	
*	Input: Files generated in DS_APP_BOOTSTRAP.do 
* 		and mw_states.dta generated in DS_MINWAGE.do
********************************************************************************


if ${scratch} == 1 {

	* --------- STORE OMEGAS FOR ALL CONTROLS IN ONE FILE 

	foreach state of global states {
		use "output/bs_states/bs_ome_`state'.dta", clear
		gen statefip = `state'
		keep if rep==0
		save "output/bs_states/bs_ome_`state'_point.dta", replace
	}

	use "output/bs_states/bs_ome_0_point.dta", clear
	gettoken first statesrest : (global) states
	
	foreach state of local statesrest {
		append using "output/bs_states/bs_ome_`state'_point.dta"
	}
	save "output/bs_states/omegas.dta", replace


	* -------- EXPORT AND ANALYZE MEAN TIME SERIES

	use "${CARD_input}/cps_clean_data_wage.dta", clear
	
	* AVERAGE WAGES TIME SERIES FOR "CARD CONTROL"
	keep if com_group==1
	qui bys year: egen Y_num = total(wage_h*earnwt* !missing(wage_h, earnwt))
	qui bys year: egen Y_den = total(earnwt* !missing(wage_h, earnwt))
	qui gen YMEAN = Y_num/Y_den

	collapse meanwage=YMEAN, by(year)
	gen statefip = 0
	save "output/mean_ts.dta", replace

	* AVERAGE WAGES TIME SERIES BY STATE:

	use "${CARD_input}/cps_clean_data_wage.dta", clear
	qui bys year statefip: egen Y_num = total(wage_h*earnwt* !missing(wage_h, earnwt))
	qui bys year statefip: egen Y_den = total(earnwt* !missing(wage_h, earnwt))
	qui gen YMEAN = Y_num/Y_den

	sum YMEAN if statefip==6 & year==1987 // 1987 reference average wage; statefip=6: California

	collapse (mean) meanwage=YMEAN, by(year statefip)
	append using "output/mean_ts.dta"
	label define statefip_lbl 0 "Card Control", add
	sort statefip year 
	save "output/mean_ts.dta", replace

	* GET NORMALIZED WAGES USING OMEGAS

	merge m:1 statefip using "output/bs_states/omegas.dta", keepusing(statefip ome_0 ome_1 ome_0_res ome_1_res) nogen
	
	* double selection:
	gen meanwage_norm = ome_0 + ome_1*meanwage
	replace meanwage_norm = meanwage if statefip==6

	* single selection (levels):
	gen meanwage_norm_lev = ome_0_res + meanwage
	replace meanwage_norm_lev = meanwage if statefip==6
	
	* single selection (proportional):
	gen meanwage_norm_ln = ome_1_res*meanwage
	replace meanwage_norm_ln = meanwage if statefip==6

	* GET MINIMUM WAGES FROM EXTERNAL DATA SET

	merge m:1 statefip year using "minwagedata/mw_states.dta", keepusing(statefip year mw MIN_CAL_YEAR) nogen 
	replace MIN_CAL_YEAR = 1991 if statefip == 0
	drop if meanwage == .
	save "output/mean_ts.dta", replace

}
	


* ----------------------------------------------------------------------------------
* PLOT MEAN TIME SERIES FIGURES
* ----------------------------------------------------------------------------------

use "output/mean_ts.dta", clear

* EACH FIGURE PLOTS TIME SERIES OF MEAN WAGE, NORMALIZED MEAN WAGE, NORMALIZED (SINGLE SELECTION) MEAN WAGE
* ALONG WITH CALIFORNIA
* MARKERS OF "CONTROL" ARE HOLLOWED FOR THOSE YEARS IN WHICH STATE IS SUBJECT TO MINIMUM WAGE INCREASE 

* 1: CARD CONTROL AND ALL INDIVIDUAL "CONTROL" STATES

foreach s of global states {
    
    sum MIN_CAL_YEAR if statefip==`s' 
    local polyearc = r(mean)

    if `s' == 6 continue
    local sname : label (statefip) `s'
    twoway (scatter meanwage year if statefip==6, msize(medium) msymbol(O)) ///
           (scatter meanwage year if statefip==`s', msize(medium) msymbol(D)) ///
           (scatter meanwage_norm year if statefip==`s', msize(medium) msymbol(T)) ///
           (scatter meanwage year if statefip==`s' & year>=MIN_CAL_YEAR, msize(medium) msymbol(D) pstyle(p2) mfcolor(white)) ///
           (scatter meanwage_norm year if statefip==`s' & year>=MIN_CAL_YEAR, msize(medium) msymbol(T) pstyle(p3) mfcolor(white)), ///
	   legend(order(1 2 3) label(1 "California") label(2 "`sname'") label(3 "Normalized `sname'") rows(1) position(6) size(small)) ///
	   xtitle(Year) ytitle((Normalized) wage) xscale(range(1983.5 1991.5)) xlabel(1984(1)1991) name(meanwage_ts_`s', replace) ///
	   xline(1988, lcolor(red) lpattern(dash)) xline(`polyearc', lcolor(red) lpattern(dash))
    graph export output/figures/STEP0_mw_`s'.eps, replace
    
    * SAME FIGURE; ADDING SINGLE SELECTION NORMALIZATIONS TO IT
    local sname : label (statefip) `s'
	twoway (scatter meanwage year if statefip==6, msize(medium) msymbol(O)) ///
		(scatter meanwage year if statefip==`s', msize(medium) msymbol(D)) ///
		(scatter meanwage_norm year if statefip==`s', msize(medium) msymbol(T)) ///
		(scatter meanwage_norm_lev year if statefip==`s', msize(large) msymbol(x)) ///
		(scatter meanwage_norm_ln year if statefip==`s', msize(medium) msymbol(.)) ///
		(scatter meanwage year if statefip==`s' & year>=MIN_CAL_YEAR, msize(medium) msymbol(D) pstyle(p2) mfcolor(white)) ///
		(scatter meanwage_norm year if statefip==`s' & year>=MIN_CAL_YEAR, msize(medium) msymbol(T) pstyle(p3) mfcolor(white)), ///
		legend(order(1 2 3 4 5) label(1 "California") label(2 "`sname'") label(3 "Normalized (Double Selection)") label(4 "Single Selection (Levels)") label(5 "Single Selection (Proportional)")  rows(2) position(6) size(small)) ///
		xtitle(Year) ytitle((Normalized) wage) xscale(range(1983.5 1991.5)) xlabel(1984(1)1991) name(meanwage_ts_`s', replace) ///
		xline(1988, lcolor(red) lpattern(dash)) xline(`polyearc', lcolor(red) lpattern(dash))
    graph export output/figures/STEP0_mw_`s'_did.eps, replace
    graph close _all
}


* ----------------------------------------------------------------------------------
* PLOT MEAN TIME SERIES FIGURES FOR DOUBLE SELECTION STATES WITH SIG POL EFFECT
* ----------------------------------------------------------------------------------

* 1. MEAN TIME SERIES

* one scatter per statefip value; the legend text is read off the statefip
* value labels, so adding a state to -slist- is all that is needed
* solid symbols, cycled (wraps around if -slist- has more than 4 entries),

local syms O D T S
local plotcmd ""
local hollow  ""
local legord  ""
local leglab  ""
local k = 0
foreach s of global statesds {
	local ++k
	local si = mod(`k'-1, 4) + 1
	local sym : word `si' of `syms'
	local sname : label (statefip) `s'
	local plotcmd `"`plotcmd' (scatter meanwage year if statefip==`s', msize(medium) msymbol(`sym'))"'
	* hollow overlay from the state's own minimum-wage year onwards
	* (white fill over the solid marker); California is never hollowed.
	* Drawn at the end, so legend numbering and scheme colours
	* are unaffected; -pstyle(p`k')- borrows state `k''s colour/symbol.
	if `s' != 6 {
	local hollow `"`hollow' (scatter meanwage year if statefip==`s' & year>=MIN_CAL_YEAR, msize(medium) msymbol(`sym') pstyle(p`k') mfcolor(white))"'
	}
	local legord  `"`legord' `k'"'
	local leglab  `"`leglab' label(`k' "`sname'")"'
}

twoway `plotcmd' `hollow', ///
legend(order(`legord') `leglab' rows(2) position(6) size(small)) ///
xtitle(Year) ytitle(Wage) xscale(range(1983.5 1991.5)) xlabel(1984(1)1991) name(meanwage_ts_agg, replace) ///
xline(1988, lcolor(red) lpattern(dash)) xline(1991, lcolor(red) lpattern(dash))
graph export output/figures/STEP0_mw_ds.eps, replace

* 2. NORMALIZED TIME SERIES

local syms O D T S
local plotcmd ""
local hollow  ""
local legord  ""
local leglab  ""
local k = 0
foreach s of global states {
	local ++k
	local si = mod(`k'-1, 4) + 1
	local sym : word `si' of `syms'
	local sname : label (statefip) `s'
	local plotcmd `"`plotcmd' (scatter meanwage_norm year if statefip==`s', msize(medium) msymbol(`sym'))"'
	* hollow overlay from the state's own minimum-wage year onwards
	* (white fill over the solid marker); California is never hollowed.
	if `s' != 6 {
		local hollow `"`hollow' (scatter meanwage_norm year if statefip==`s' & year>=MIN_CAL_YEAR, msize(medium) msymbol(`sym') pstyle(p`k') mfcolor(white))"'
	}
	local legord  `"`legord' `k'"'
	local leglab  `"`leglab' label(`k' "`sname'")"'
}

twoway `plotcmd' `hollow', ///
legend(order(`legord') `leglab' rows(2) position(6) size(small)) ///
xtitle(Year) ytitle(Normalized wage) xscale(range(1983.5 1991.5)) xlabel(1984(1)1991) name(meanwage_adj_ts_agg, replace) ///
xline(1988, lcolor(red) lpattern(dash)) xline(1991, lcolor(red) lpattern(dash))

graph export output/figures/STEP0_mw_adj_ds.eps, replace

*
