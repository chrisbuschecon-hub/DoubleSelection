********************************************************************************
*	REPLICATION OF RESULTS TABLES FOR "Double Selection in Causal Inference"
*	by
*	Alemán, Christian
*	Busch, Christopher
*	Santaeulàlia-Llopis, Raül
*	Surovtseva, Tetyana
*	(c) October 2026
*	contact: christopher.busch@econ.lmu.de
*
*	DS_APP_BOOTSTRAP.do
*	- implements the double selection estimator 	
*	- runs bootstrap for each state as control for California
*	
*	output: tables that summarize both steps of 
*	two-step double selection estimator
*	(Tables 3, B.1, B.2, B.3, B.4, B.5)
*	
*	Input:
*	- minimum wage data generated in DS_APP_MINWAGE.do
*	- generated CPS sample
********************************************************************************

capture program drop ds_bootstrap
program define ds_bootstrap, rclass
    * Bootstrap the WHOLE DS PROCEDURE. Each replication resamples individuals
    * with replacement within statefip x year cells (bsample, strata(...)), so
    * every cell size is held at its observed N, then rebuilds YT and YC, runs
    * the normalization regressions, generates normalized wage variables,
    * runs the event study. 
    *
    * Expects in memory: wage_h lwage_h statefip year TREAT TREAT_POS TREAT_POSTPOL
    * Leaves the data as it found it (preserve/restore).
    
    syntax , REPS(integer) BASEyear(integer) ///
        [SEED(integer 20260721) OUTcomes(string) ///
         RESULTSframe(name) POLyearc(integer 1991) NOIsily]

    if "`outcomes'" == "" local outcomes wage_h lwage_h wage_tilde wage_tilde_ln wage_tilde_lev
    if "`resultsframe'" == "" local resultsframe bs_es

    set seed `seed'
    qui levelsof year, local(yearlist)

    qui tempfile bsfile
    tempname pf
    postfile `pf' int rep str32 outcome int yr double b ///
        using "`bsfile'", replace

    * separate file for the normalization (first-stage) coefficients: one row per
    * rep, since they are not outcome- or horizon-specific.
    *   ome_0     = intercept of unrestricted adjustment (YT on YC, with cons)
    *   ome_1     = slope     of unrestricted adjustment
    *   ome_1_res = slope     of restricted adjustment (nocons)
    qui tempfile omefile
    tempname pfome
    postfile `pfome' int rep double ome_0 double ome_1 double ome_1_res ome_0_res ///
        using "`omefile'", replace

    di as txt _n "Bootstrapping DS: `reps' reps, outcomes: `outcomes'"

    preserve
    * r = 0 is the ORIGINAL sample; r = 1..reps are the bootstrap replications
    
    forvalues r = 0/`reps' {

        * BACK TO ORIGINAL SAMPLE (r=0), THEN RESAMPLE (r>0) within statefip x year
        restore, preserve
        if `r' > 0 qui bsample, strata(statefip year)

        * TEMPORARY VARIABLES AND NORMALIZED etc.
        capture drop wage_t wage_c YT YC yfirst X wage_tilde wage_tilde_ln wage_tilde_lev 
	
	* -------------------------
	* FIRST STEP: NORMALIZATION
	* -------------------------
	
	qui gen wage_t = wage_h*TREAT
        qui replace wage_t = . if TREAT==0
        qui gen wage_c = wage_h*(TREAT==0)
        qui replace wage_c = . if TREAT==1
	
	* MEAN WAGE OF GROUP T (earnwt is sample weight)
	qui bys year: egen YT_num = total(wage_t*earnwt* !missing(wage_t, earnwt))
	qui bys year: egen YT_den = total(earnwt* !missing(wage_t, earnwt))
	qui gen YT = YT_num/YT_den
	drop YT_num YT_den
	
	* MEAN WAGE OF GROUP C (earnwt is sample weight)
	qui bys year: egen YC_num = total(wage_c*earnwt* !missing(wage_c, earnwt))
	qui bys year: egen YC_den = total(earnwt* !missing(wage_c, earnwt))
	qui gen YC = YC_num/YC_den
	drop YC_num YC_den

	* indicator to only use one observation per year and group in the 
	* first-step normalization regression
	
        qui gen yfirst = .
        qui bys year TREAT: gen X = _n
        qui replace yfirst = X if X==1

        * DOUBLE SELECTION (UNRESTRICTED) NORMALIZATION
        qui reg YT YC if yfirst==1 & TREAT==1 & year<TP
        local ome_0 = _b[_cons]
        local ome_1 = _b[YC]
        qui gen wage_tilde = wage_h
        qui replace wage_tilde = _b[_cons] + _b[YC]*wage_h if TREAT==0

        * SINGLE SELECTION (PROPORTIONAL) NORMALIZATION
        qui reg YT YC if yfirst==1 & TREAT==1 & year<TP, nocons
        local ome_1_res = _b[YC]
        qui gen wage_tilde_ln = wage_h
        qui replace wage_tilde_ln = _b[YC]*wage_h if TREAT==0

        * SINGLE SELECTION (LEVELS) NORMALIZATION
	gen YDIFF = YT - YC
        qui reg YDIFF if yfirst==1 & TREAT==1 & year<TP
        local ome_0_res = _b[_cons]
        qui gen wage_tilde_lev = wage_h
        qui replace wage_tilde_lev = _b[_cons] + wage_h if TREAT==0
	
        post `pfome' (`r') (`ome_0') (`ome_1') (`ome_1_res') (`ome_0_res') 

        * -------------------------
	* SECOND STEP: TREATMENT EFFECT
	* -------------------------
	
        foreach y of local outcomes {

            qui reg `y' i.TREAT i.year b`baseyear'.year#i.TREAT [pweight=earnwt]

            foreach yr of local yearlist {
                if `yr' == `baseyear' {
                    local bb = 0
                }
                else {
                    local bb = .
                    capture local bb = _b[`yr'.year#1.TREAT]
                }
                post `pf' (`r') ("`y'") (`yr') (`bb') 
            }
        }

        if "`noisily'" != "" | mod(`r', 5) == 0 di as txt "      rep `r' / `reps'"
    }
    restore

    postclose `pf'
    postclose `pfome'

    * --- load the replication draws into a frame ---
    capture frame drop `resultsframe'
    frame create `resultsframe'
    frame `resultsframe' {
        qui use "`bsfile'", clear
        label var b   "event-study coefficient"
        di as txt _n "Bootstrap draws stored in frame -`resultsframe'-:"
        qui count
        di as txt "  `r(N)' rows (`reps' reps x outcomes x horizons)"
    }

    * --- load the normalization-coefficient draws into a frame ---
    local omeframe `resultsframe'_ome
    capture frame drop `omeframe'
    frame create `omeframe'
    frame `omeframe' {
        qui use "`omefile'", clear
        label var ome_0     "normalization intercept (unrestricted)"
        label var ome_1     "normalization slope (unrestricted)"
        label var ome_1_res "normalization slope (restricted, nocons)"
	label var ome_0_res "normalization intercept (restricted, slope=1)"

        di as txt _n "normalization coefficients (frame -`omeframe'-):"
        di as txt "  original sample (rep 0) and `reps' bootstrap draws"

        foreach v in ome_0 ome_1 ome_1_res ome_0_res {
            qui summarize `v' if rep==0, meanonly
            local o = r(mean)
            qui summarize `v' if rep>0
            di as txt "  `v': orig = " as res %9.4f `o' ///
                as txt "  bs SE = " as res %9.4f r(sd)
        }
    }

    return local resultsframe "`resultsframe'"
    return local omeframe "`omeframe'"
    return scalar reps = `reps'
end

********************************************************************************
******************************************

*******************************************************************************
******************************************************************************



* LOOP OVER STATES

foreach state of global states {
	
	frames reset
	use "${CARD_input}/cps_clean_data_wage.dta", clear

	
	** PICK CONTROL
	
	if `state' == 0 {
		keep if statefip == 6 | com_group == 1  //Card Control
		local statename "Card Control"
		local polyearc 1991
	}
	
	else {
		keep if statefip == 6 | statefip == `state' 
		local statename : label (statefip) `state'
		merge m:1 statefip year using "minwagedata/mw_states.dta", keepusing(statefip year mw MIN_CAL) nogen keep(match)
		keep if statefip < . 
		
		sum year if statefip==`state' & MIN_CAL==1
		local polyearc = r(min)
	}
	
	gen TP = 1988
	gen TREAT = statefip == 6
	gen TREAT_POS = year>TP
	gen TREAT_POSTPOL = TREAT*TREAT_POS

	* --- bootstrap DS (set bootreps 0 to skip) ---
	if ${bootreps} > 0 {
		di as txt " "
		di as txt "State `state' : `statename'"
		di as txt " "
    		ds_bootstrap, reps(${bootreps}) baseyear(1987) ///
		outcomes(wage_h lwage_h wage_tilde wage_tilde_ln wage_tilde_lev) ///
		resultsframe(bs_es_`state') polyearc(`polyearc')
		frame bs_es_`state': save "output/bs_states/bs_es_`state'.dta", replace
		frame bs_es_`state'_ome: save "output/bs_states/bs_ome_`state'.dta", replace
	}		
	
	
} //state

*

*
