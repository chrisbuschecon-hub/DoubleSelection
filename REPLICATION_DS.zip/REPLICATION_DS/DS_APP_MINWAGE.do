********************************************************************************
*	REPLICATION OF RESULTS TABLES FOR "Double Selection in Causal Inference"
*	by
*	Alemán, Christian
*	Busch, Christopher
*	Santaeulàlia-Llopis, Raül
*	Surovtseva, Tetyana
*	(c) October 2026
*	contact: christopher.busch@econ.lmu.de
*
*	DS_APP_MINWAGE.do
*	output: data set with minimum wage info by state x year
*	
*	Input: "Historical state and sub-state minimum wage data" 
*	by Vaghul, Kavya and Ben Zipperer, Sep. 2016, Washington Center for
* 	Equitable Growth: mw_state_annual.dta 
********************************************************************************

use "minwagedata/mw_state_annual.dta", clear

gen mw = max(max_fed_mw,max_mw)

gen MIN_CAL = 0
replace MIN_CAL = 1 if mw>=4.25

rename statefips statefip


gen MIN_CAL89temp = MIN_CAL*(year==1989) 
gen MIN_CAL90temp = MIN_CAL*(year==1990)
sort statefip year
by statefip: egen MIN_CAL89 = max(MIN_CAL89temp)
by statefip: egen MIN_CAL90 = max(MIN_CAL90temp)
gen MIN_CAL8990 = MIN_CAL89+MIN_CAL90
drop MIN_CAL89 MIN_CAL89temp MIN_CAL90 MIN_CAL90temp

bys statefip: egen MIN_CAL_YEAR_t = min(year) if MIN_CAL==1
by statefip: egen MIN_CAL_YEAR = max(MIN_CAL_YEAR_t)
drop MIN_CAL_YEAR_t



save "minwagedata/mw_states.dta", replace

*
