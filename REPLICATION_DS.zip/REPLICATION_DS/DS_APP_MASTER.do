********************************************************************************
*	REPLICATION OF RESULTS TABLES FOR "Double Selection in Causal Inference"
*	by
*	Alemán, Christian
*	Busch, Christopher
*	Santaeulàlia-Llopis, Raül
*	Surovtseva, Tetyana
*	(c) October 2026
*	contact: christopher.busch@econ.lmu.de
*
*	SEQUENTIALLY RUNS THE DO-FILES WHICH GENERATE ALL RESULTS IN PAPER
*	
*	Input:
*	- minimum wage data stored in subfolder /minwagedata
* 	- CPS data sample stored in subfolder /input/raw
********************************************************************************


** -----------------------------------------------------------------------------
* SETUP
set scheme plotplainblind
clear all

global CARD "[FOLDER OF REPLICATION_DS]"
global CARD_input "${CARD}/input"

global gencpsdata 0 // 1: extract cps sample from raw data
global scratch 0 // 1: run estimation on cps sample and store results
global bootreps 500 //sets number of bootstrap repetitions; 
		   //note: random numner seed is set in ds_bootstrap program

global states 0 1 2 4 5 8 9 10 11 12 13 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35  36 37 38 39 40 41 42 44 45 46 47 48 49 50 51 53 54 55 56

cd ${CARD}

* ---------
* GENERATE CPS SAMPLE FOR ANALYSIS
* ---------
if ${gencpsdata}==1 {
	do DS_APP_CLEAN_CPS.do
}

* ---------
* EXTRACT MINIMUM WAGE DATA (Vaghul/Zipperer 2016 dataset)
* ---------
if ${scratch}==1 { 
	do DS_APP_MINWAGE.do
}

* ---------
* IMPLEMENT DOUBLE SELECTION ESTIMATOR WITH BOOTSTRAP
* ---------
if ${scratch}==1 { 
	do DS_APP_BOOTSTRAP.do
}

* ---------
* GENERATE TIME SERIES PLOTS OF MEAN AND NORMALIZED MEAN BY STATES
* ---------

global statesds 6 20 22 25 32 36 53 56 // DS + pre passed + sig effect 

do DS_APP_GEN_TIMESERIES.do

* ---------
* GENERATE TABLES THAT SUMMARIZE ALL RESULTS
* ---------

do DS_APP_GEN_TABLES.do

* ---------
* GENERATE FIGURES OF FIRST-STEP (OUTCOME-ON-OUTCOME) AND SECOND-STEP (EVENT STUDY)
* ---------

do DS_APP_GEN_FIGS.do

*
