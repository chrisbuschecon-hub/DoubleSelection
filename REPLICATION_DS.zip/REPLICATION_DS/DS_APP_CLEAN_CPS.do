********************************************************************************
*	REPLICATION OF RESULTS TABLES FOR "Double Selection in Causal Inference"
*	by
*	Alemán, Christian
*	Busch, Christopher
*	Santaeulàlia-Llopis, Raül
*	Surovtseva, Tetyana
*	(c) October 2026
*	contact: christopher.busch@econ.lmu.de
*
*	DS_APP_CLEAN_CPS.do
*	
*	Input:
*	- CPS data sample stored in subfolder /input; fetched via IPUMS
********************************************************************************

/*
*CPS VARIABLES USED:

statefip	state identifier
metfips		metropolitan area identifier
year
age
empstat		employment status
labforce	labor force indicator
ind1950		industry coding
ind1990		industry coding
hourwage	hourly wage
paidhour	indicator: workek by hour yes/no
uhrswork1	usual hours worked
earnweek	weekly earnings
earnwt		earnings weight
serial		household identifier
month		
pernum		person number wihthin household

*/

clear all

*----------------------------------------------------------------------------
* Load Data
*----------------------------------------------------------------------------
use "${CARD_input}/raw/cps_raw_data", clear

*------------------------------------------------------------------
* GROUP INDICATORS
*------------------------------------------------------------------


* Create Card's Group of Control States: 
* Arizona, Florida, Georgia, New Mexico, and Dallas-Fort Worth, Texas
gen com_group = 0
replace com_group = 1 if statefip==4 /*4: Arizona*/
replace com_group = 1 if statefip==12 /*12: Florida*/
replace com_group = 1 if statefip==13 /*13: Georgia*/
replace com_group = 1 if statefip==35 /*35: New Mexico*/
replace com_group = 1 if metfips==1920 /*1987: Dallas Texas*/
replace com_group = 1 if metfips==2800 /*1987: Fort Worth-Arlington Texas*/

*----------------------------------------------------------------------------
* Start Trimming
*----------------------------------------------------------------------------
* Drop if not in working age (Same definition as Card 16-68) 
drop if age>=69 /*2,872,640  Deleted */
*drop if age>=20 /*XX  Deleted */
drop if age<=15 /*6,742,406  Deleted */ /*N = 22,617,201*/ 

* -----------------------------------------------------------------------------
* SAMPLE FOR WAGE ANALYSIS
* -----------------------------------------------------------------------------

************

keep if year>=1984 & year<=1991

* Drop if not employed
keep if empstat==10 | empstat==12  /*7,568,607*/ /*N = 15,048,594 */

* Verify everyone is employed
tab empstat

* Verify all in labor force
tab labforce

* Drop part time workers
*keep if wkstat==10  | empstat==11

* Generate retail dummy
gen ret1950 = 0
replace ret1950 = 1 if ind1950>=636 &  ind1950<700 /* Without whole sale*/
*replace ret1950 = 1 if ind1950>=606 &  ind1950<700 /* With whole sale*/

gen ret1990 = 0
replace ret1990 = 1 if ind1990>=580 & ind1990<700  /* Without whole sale*/
*replace ret1990 = 1 if ind1990>=500 & ind1990<700  /* With whole sale*/

* Create Employment dummy
gen emp = 0
replace emp = 1 if empstat ==10

*--------------------------------------------------------------------------
* Create Hourly wage variable
*------------------------------------------------------------------

gen wage_h = hourwage if paidhour == 2 

* Treat the hours per week variable
* Drop if negative hours
drop if uhrswork1<=0  /*2,451  Deleted*/ /*N = 15,046,143 */
drop if uhrswork1==. /*4,621,715 Deleted*/ /*N = 10,424,428 */

* If people dont sleep
drop if uhrswork1>168 /* 168 max hours in a 7 day week minus 2 hours sleep per day = 168-14*/   /*7,607,367 Deleted */ /*N = 2,817,061 */

* Treat the earnigs per week (on primary job) variable
* Drop if negative (pre_tax) yearly wages
drop if earnweek<=0 /*0  Deleted*/ /*N = N = 2,817,061 */
drop if earnweek==. /*O Deleted*/

gen centile_wage = .
forval y = 1984/1991 {
	qui sum earnweek if year==`y', d
	replace centile_wage = 1 if earnweek>=r(p99) & year==`y'
}
drop if centile_wage==1
replace wage_h = earnweek/uhrswork1 if paidhour != 2


gen lwage_h = log(wage_h)

drop if wage_h<1 
keep if ret1950==1

keep statefip com_group year wage_h lwage_h earnwt

save "${CARD_input}/cps_clean_data_wage.dta", replace



*
