********************************************************************************
*	REPLICATION OF RESULTS TABLES FOR "Double Selection in Causal Inference"
*	by
*	Alemán, Christian
*	Busch, Christopher
*	Santaeulàlia-Llopis, Raül
*	Surovtseva, Tetyana
*	(c) October 2026
*	contact: christopher.busch@econ.lmu.de
*
*	DS_APP_GEN_TABLES.do
*	output: tables that summarize both steps of 
*	two-step double selection estimator
*	(Tables 3, B.1, B.2, B.3, B.4, B.5)
*	
*	Input: Files generated in DS_APP_BOOTSTRAP.do
*	and output/mean_ts.dta generated in DS_APP_GEN_TIMESERIES
********************************************************************************


* -----------------------------------------------
capture program drop ds_bootstrap_summarize
program define ds_bootstrap_summarize
    * Collapse the draws into bootstrap SEs and percentile CIs, per outcome x horizon.
    syntax , [RESULTSframe(name) SAVEframe(name) LEVEL(real 90)]

    if "`resultsframe'" == "" local resultsframe bs_es
    if "`saveframe'"    == "" local saveframe bs_es_summary

    local lo = (100-`level')/2
    local hi = 100 - `lo'

    * collapse's (p#) only takes integer percentiles, so the per-group stats
    * are built with _pctile (which accepts fractional percentiles) instead.
    tempfile sfile
    tempname pf
    postfile `pf' str32 outcome int yr ///
        double b_orig double b_mean double b_se double b_lo double b_hi ///
        using "`sfile'", replace

    frame `resultsframe' {
        qui levelsof outcome, local(outs)
        qui levelsof yr, local(yrs)

        foreach o of local outs {
            foreach y of local yrs {
                * rep 0 = original-sample point estimate; reps 1+ = the draws
                qui count if outcome=="`o'" & yr==`y' & rep>0
                if r(N) == 0 continue

                local bo = .
                qui summarize b if outcome=="`o'" & yr==`y' & rep==0, meanonly
                if r(N) > 0 local bo = r(mean)

                qui summarize b if outcome=="`o'" & yr==`y' & rep>0
                local bm = r(mean)
                local bs = r(sd)
                qui _pctile b if outcome=="`o'" & yr==`y' & rep>0, p(`lo' `hi')
                local blo = r(r1)
                local bhi = r(r2)

                post `pf' ("`o'") (`y') (`bo') (`bm') (`bs') (`blo') (`bhi')
            }
        }
    }
    postclose `pf'

    capture frame drop `saveframe'
    frame create `saveframe'
    frame `saveframe' {
        qui use "`sfile'", clear
        label var b_se   "bootstrap SE of event-study coef"
        sort outcome yr
        di as txt _n "Event-study coefficients by horizon (`level'% percentile CI):"
        list outcome yr b_orig b_se b_lo b_hi, sepby(outcome) noobs
    }
end
* -----------------------------------------------


* outcomes to tabulate: STEP1 gets one matrix, STEP2 one matrix per outcome
* (STEP2_wage_tilde, STEP2_wage_h, STEP2_lwage_h, ...). 
* Clear anything left over from a previous run


local tabouts wage_h lwage_h wage_tilde wage_tilde_ln wage_tilde_lev

* STEP1_EXPORT: consolidated first-stage estimates (coef, bs SE, 90% CI)
capture matrix drop STEP1_EXPORT

* ES_export_wage_tilde: per-horizon event-study coef / bootstrap SE / CI for wage_tilde 
* and for the other variables
foreach o in wage_tilde wage_tilde_lev wage_tilde_ln lwage_h {
	capture matrix drop ES_export_`o'
}

* LOOP OVER STATES:

foreach state of global states {
	
	frame reset

	
	use "output/mean_ts.dta", replace
	keep if statefip == 6 | statefip == `state'
	local statename : label (statefip) `state'

	sum MIN_CAL_YEAR if statefip==`state', meanonly
	local polyearc = r(mean)
	
		
		
	*****************************************************************	
	frame create bs_es_`state'
	frame bs_es_`state': use "output/bs_states/bs_es_`state'.dta"
	
	frame create bs_es_`state'_ome
	frame bs_es_`state'_ome: use "output/bs_states/bs_ome_`state'.dta"
		
	frame bs_es_`state'_ome {	
		qui summarize ome_0 if rep==0, meanonly
		local b_o0 = r(mean)
		qui summarize ome_0 if rep>0
		local s_o0 = r(sd)
		qui summarize ome_1 if rep==0, meanonly
		local b_o1 = r(mean)
		qui summarize ome_1 if rep>0
		local s_o1 = r(sd)
		qui summarize ome_0_res if rep==0, meanonly
		local b_o0r = r(mean)
		qui summarize ome_0_res if rep>0
		local s_o0r = r(sd)
		qui summarize ome_1_res if rep==0, meanonly
		local b_o1r = r(mean)
		qui summarize ome_1_res if rep>0
		local s_o1r = r(sd)
	}

	* --- 90% bootstrap percentile CIs (5th/95th pct of the rep>0 draws) for
	*     the four adjustment coefficients, reported next to each estimate ---
	frame bs_es_`state'_ome {
		foreach v in ome_0 ome_1 ome_0_res ome_1_res {
			qui _pctile `v' if rep>0, p(5 95)
			local lo_`v' = r(r1)
			local hi_`v' = r(r2)
		}
	}

	* --- STEP1_EXPORT: the four adjustment coefficients, each followed by its
	*     bootstrap SE and 90% percentile CI; nothing else ---
	local rn = strtoname("`statename'")

	matrix rowx = (`state', ///
	               `b_o0',  `s_o0',  `lo_ome_0',     `hi_ome_0', ///
	               `b_o1',  `s_o1',  `lo_ome_1',     `hi_ome_1', ///
	               `b_o0r', `s_o0r', `lo_ome_0_res', `hi_ome_0_res', ///
	               `b_o1r', `s_o1r', `lo_ome_1_res', `hi_ome_1_res')
	matrix colnames rowx = state ///
	               ome_0     se_ome_0     lo_ome_0     hi_ome_0 ///
	               ome_1     se_ome_1     lo_ome_1     hi_ome_1 ///
	               ome_0_res se_ome_0_res lo_ome_0_res hi_ome_0_res ///
	               ome_1_res se_ome_1_res lo_ome_1_res hi_ome_1_res
	matrix rownames rowx = `rn'
	capture confirm matrix STEP1_EXPORT
	if _rc matrix STEP1_EXPORT = rowx
	else   matrix STEP1_EXPORT = STEP1_EXPORT \ rowx

	
	* STEP 2: Event Study Tables


	* --- DS_BS = 1 if the 90% bootstrap CI of ome_0 excludes 0 AND the 90%
	*     bootstrap CI of ome_1 excludes 1 ---

	frame bs_es_`state'_ome {
		qui _pctile ome_0 if rep>0, p(5 95)
		local o0_lo = r(r1)
		local o0_hi = r(r2)
		qui _pctile ome_1 if rep>0, p(5 95)
		local o1_lo = r(r1)
		local o1_hi = r(r2)
	}
	local DS_BS = ((`o0_lo'>0) | (`o0_hi'<0)) & ((`o1_lo'>1) | (`o1_hi'<1))

	* collect event study bootstrap results (also store for later printing)
	qui ds_bootstrap_summarize, resultsframe(bs_es_`state') ///
	saveframe(bs_sum_`state') level(90)
	frame bs_sum_`state': save "output/bs_states/bs_sum_`state'.dta", replace


	
	* --------------------------------------------------------------------------------
	* --- ES_wage_tilde / ES_wage_tilde_lev / ES_wage_tilde_ln tables: 
	*     for each outcome, the event-study
	*     coefficient (original sample, b_orig), its bootstrap SE and the
	*     bootstrap CI at selected horizons; one row per state, columns
	*     b_<yr> b_se_<yr> b_lo_<yr> b_hi_<yr>. Missing horizons post as . ---
	local es_years 1984 1985 1986 1989 1990

	foreach var in wage_tilde wage_tilde_lev wage_tilde_ln lwage_h {
		local es_vals  ""
		local es_names ""
		foreach y of local es_years {
			foreach v in b_orig b_se b_lo b_hi {
				local val = .
				frame bs_sum_`state' {
					qui summarize `v' if outcome=="`var'" & yr==`y', meanonly
					if r(N) > 0 local val = r(mean)
				}
				if `y' >= `polyearc' local val = .
				local es_vals `es_vals', `val'
				local vn : subinstr local v "b_orig" "b"
				local es_names `es_names' `vn'_`y'
			}
		}

		* --- indicators appended as extra columns:
		frame bs_sum_`state' {
			qui count if outcome=="`var'" & yr<1987
			local npre = r(N)
			qui count if outcome=="`var'" & yr<1987 & b_lo<0 & b_hi>0
			local ncov = r(N)
		}
		local PRE = (`npre'>0) & (`ncov'==`npre')
		* --- SIG_89 / SIG_90: 1 if the year's bootstrap CI excludes zero AND the
		*     pretest PRE (= pre_all_t) is passed; 0 otherwise; missing if the
		*     horizon is blanked by the polyearc rule or absent from the summary ---
		foreach sy in 1989 1990 {
			local sfx = substr("`sy'", 3, 2)
			local SIG_`sfx' = .
			if `sy' < `polyearc' {
				frame bs_sum_`state' {
					qui summarize b_lo if outcome=="`var'" & yr==`sy', meanonly
					local slo = r(mean)
					qui summarize b_hi if outcome=="`var'" & yr==`sy', meanonly
					local shi = r(mean)
				}
				if `slo'<. & `shi'<. local SIG_`sfx' = ((`slo'>0) | (`shi'<0)) & `PRE'
			}
		}
		* horizon-only lists, kept aside for the consolidated ES_export_* row
		local es_vals_yr  `es_vals'
		local es_names_yr `es_names'

		* --- ES_export_`var': DS_BS and PRE  first, then horizons ---
		matrix rowex = (`state', `DS_BS', `PRE'`es_vals_yr', `SIG_89', `SIG_90')
		matrix colnames rowex = state DS_BS PRE `es_names_yr' SIG_89 SIG_90
		matrix rownames rowex = `rn'
		capture confirm matrix ES_export_`var'
		if _rc matrix ES_export_`var' = rowex
		else   matrix ES_export_`var' = ES_export_`var' \ rowex
	}

	frame drop bs_es_`state'
	frame drop bs_es_`state'_ome
} //state


di as txt _n "STEP1_EXPORT: first-stage estimates with bootstrap SE and 90% CI"
matrix list STEP1_EXPORT, format(%9.4f)


local aggexcl "!inlist(state, 0)"

* --- ES_SUMMARY: one row per estimator, with the number of states passing the
*     pre-test (PRE==1), the number of those with first-step support for double
*     selection, then per horizon the mean / min / max / N of the significant
*     post-policy estimates among pre-test passers (ES_MEANS_SIG selection).
*     Aggregate pseudo-states are excluded throughout, as in ES_MEANS(_SIG).
*     Row labels are the estimator names; the row-label column is headed
*     "Estimator" in the sheet. ---
capture matrix drop ES_SUMMARY

* first-step reliability flag, by state, from STEP1_EXPORT: the double
* selection first step is UNRELIABLE if ome_0 or ome_1 lies outside its own
* 90% bootstrap CI (large bootstrap bias). Such states are dropped from every
* statistic in the Double Selection row of ES_SUMMARY (they keep their rows
* in the ES_export_* sheets). The single selection rows are not screened,
* since their (restricted) first steps are not affected.
tempname s1f
tempfile s1file
frame create `s1f'
frame `s1f' {
	qui svmat double STEP1_EXPORT, names(col)
	gen byte ds_unrel = (ome_0<lo_ome_0 | ome_0>hi_ome_0 | ome_1<lo_ome_1 | ome_1>hi_ome_1)
	keep state ds_unrel
	qui save "`s1file'"
}
frame drop `s1f'

local es_i = 0
foreach var in wage_tilde wage_tilde_lev wage_tilde_ln lwage_h {
	local ++es_i
	if "`var'" == "wage_tilde"     local eslab Double_Selection
	if "`var'" == "wage_tilde_lev" local eslab Single_Selection_Levels
	if "`var'" == "wage_tilde_ln"  local eslab Single_Selection_Proportional
	if "`var'" == "lwage_h"        local eslab DiD_Logs

	* Double Selection drops first-step-unreliable
	* states; the single selection and log DiD rows keep everything (the log
	* DiD does not use the first step at all)
	if "`var'" == "wage_tilde" local dsok "ds_unrel==0"
	else                       local dsok "1"

	tempname mf
	frame create `mf'
	frame `mf' {
		qui svmat double ES_export_`var', names(col)
		qui merge 1:1 state using "`s1file'", nogenerate keep(master match)
		qui replace ds_unrel = 0 if ds_unrel==.
		qui count if PRE==1 & `aggexcl' & `dsok'
		local npass = r(N)
		* ... and of those, the ones whose first step supports double selection
		qui count if PRE==1 & DS_BS==1 & `aggexcl' & `dsok'
		local npass_ds = r(N)

		* mean / min / max / N of the significant post-policy estimates among
		* pre-test passers -- same selection as ES_MEANS_SIG, so mean and N
		* reproduce that sheet; min and max are the added columns
		qui summarize b_1989 if PRE==1 & ((b_lo_1989>0 & b_lo_1989<.) | b_hi_1989<0) & b_1989>=b_lo_1989 & b_1989<=b_hi_1989 & `aggexcl' & `dsok'
		local m89 = r(mean)
		local lo89 = r(min)
		local hi89 = r(max)
		local n89 = r(N)
		qui summarize b_1990 if PRE==1 & ((b_lo_1990>0 & b_lo_1990<.) | b_hi_1990<0) & b_1990>=b_lo_1990 & b_1990<=b_hi_1990 & `aggexcl' & `dsok'
		local m90 = r(mean)
		local lo90 = r(min)
		local hi90 = r(max)
		local n90 = r(N)

		* split each year's significant set by sign (CI excludes zero, so the
		* estimate is strictly positive or strictly negative): Npos + Nneg = N
		qui count if PRE==1 & b_lo_1989>0 & b_lo_1989<. & b_1989>=b_lo_1989 & b_1989<=b_hi_1989 & `aggexcl' & `dsok'
		local npos89 = r(N)
		qui count if PRE==1 & b_hi_1989<0 & b_1989>=b_lo_1989 & b_1989<=b_hi_1989 & `aggexcl' & `dsok'
		local nneg89 = r(N)
		qui count if PRE==1 & b_lo_1990>0 & b_lo_1990<. & b_1990>=b_lo_1990 & b_1990<=b_hi_1990 & `aggexcl' & `dsok'
		local npos90 = r(N)
		qui count if PRE==1 & b_hi_1990<0 & b_1990>=b_lo_1990 & b_1990<=b_hi_1990 & `aggexcl' & `dsok'
		local nneg90 = r(N)
	}
	frame drop `mf'

	matrix srow = (`npass', `npass_ds', ///
	               `m89', `lo89', `hi89', `n89', `npos89', `nneg89', ///
	               `m90', `lo90', `hi90', `n90', `npos90', `nneg90')
	matrix colnames srow = n_pass_pretest n_pass_pretest_DS ///
	               mean_b_1989 min_b_1989 max_b_1989 N_1989 Npos_1989 Nneg_1989 ///
	               mean_b_1990 min_b_1990 max_b_1990 N_1990 Npos_1990 Nneg_1990
	matrix rownames srow = `eslab'
	capture confirm matrix ES_SUMMARY
	if _rc matrix ES_SUMMARY = srow
	else   matrix ES_SUMMARY = ES_SUMMARY \ srow
}

di as txt _n "ES_SUMMARY: states passing the pre-test, then ES_MEANS_SIG, by estimator"
matrix list ES_SUMMARY, format(%9.4f)

foreach var in wage_tilde wage_tilde_lev wage_tilde_ln lwage_h {
	di as txt _n "ES_export_`var': DS_BS, PRE, then horizon coef / SE / CI by state"
	matrix list ES_export_`var', format(%9.4f)
}

* --- export: one workbook, STEP1 on its own sheet and one sheet per outcome.
*     -names- writes the matrix row and column names, so the full state names
*     land in column A.
local xlsfile "output/DS_TABLES.xlsx"


* consolidated sheet: coefficients with bootstrap SE and 90% CI 
putexcel set "`xlsfile'", replace sheet("STEP1_EXPORT")
putexcel A1 = "STEP1_EXPORT: first-stage estimates with bootstrap SE and 90% CI by state"
putexcel A3 = matrix(STEP1_EXPORT), names nformat("0.0000")
clear 
svmat STEP1_EXPORT, names(col) 
save STEP1_EXPORT.dta, replace


* consolidated ES sheets: DS_BS, PRE, then the horizons 
foreach var in wage_tilde wage_tilde_lev wage_tilde_ln lwage_h {
	putexcel set "`xlsfile'", modify sheet("ES_export_`var'", replace)
	putexcel A1 = "ES_export (`var'): DS_BS, PRE, then event-study coef / bootstrap SE / CI by horizon and state"
	putexcel A3 = matrix(ES_export_`var'), names nformat("0.0000")
	clear 
	svmat ES_export_`var', names(col) 
	save ES_export_`var'.dta, replace
}


* by-estimator summary: # passing pre-test, then the ES_MEANS_SIG columns
putexcel set "`xlsfile'", modify sheet("ES_SUMMARY", replace)
putexcel A1 = "ES_SUMMARY: number of states passing the pre-test, then ES_MEANS_SIG, by estimator"
putexcel A3 = matrix(ES_SUMMARY), names nformat("0.0000")
putexcel A3 = "Estimator"
clear 
svmat ES_SUMMARY, names(col) 
save ES_SUMMARY.dta, replace

putexcel close

di as txt _n "Tables written to `xlsfile'"


*
