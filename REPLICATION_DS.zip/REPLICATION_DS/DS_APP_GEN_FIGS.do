********************************************************************************
*	REPLICATION OF RESULTS TABLES FOR "Double Selection in Causal Inference"
*	by
*	Alemán, Christian
*	Busch, Christopher
*	Santaeulàlia-Llopis, Raül
*	Surovtseva, Tetyana
*	(c) October 2026
*	contact: christopher.busch@econ.lmu.de
*
*	DS_APP_GEN_FIGS.do
*	output: figures of first-step normalization and second-step event-study 
*   	coefficients with bootstrap CIs of two-step double selection estimator
*	(Figures 5(b), 5(c), 7(b), 7(c), B.1, B.2)
*
*	Input: Files generated in DS_APP_BOOTSTRAP.do and in DS_APP_GEN_TABLES.do
*	and output/mean_ts.dta generated in DS_APP_GEN_TIMESERIES
********************************************************************************

********************************************************************************
* PROGRAMS: ds_fitband, ds_fitpoints, ds_eventstudy_plots 
* plot the first-step adjustment line with bootstrap confidence bands, and
* the second-step event-study coefficients with bootstrap CIs.          
********************************************************************************

capture mata: mata drop ds_fb()
mata:
// Core of -ds_fitband-. Reads the (ome_0, ome_1) draws out of -omeframe-,
// evaluates every draw's fitted line on a grid of np points spanning
// [xmin, xmax], and returns (x, fit, se, lo, hi) in the Stata matrix __fb.
//   fit = original-sample line (rep 0), or the bootstrap mean if rep 0 absent
//   se  = bootstrap sd of the fitted value at x, across draws
//   lo/hi = pointwise percentile band
// b0v == "" signals the restricted (no-constant) fit, i.e. intercept fixed 0.
// b1v == "" is the mirror image: slope fixed at 1, so the line is parallel to
// the 45-degree line and only the intercept (ome_0_res) varies across draws.

void ds_fb(string scalar omeframe, string scalar b0v, string scalar b1v,
           real scalar xmin, real scalar xmax, real scalar np,
           real scalar level)
{
    string scalar cur
    real colvector rep, b0, b1, o, d, d0, d1, x, fhat, fbar, se, sez
    real colvector lo, hi, s, tmax
    real matrix F, T
    real scalar B, o0, o1, i, a, k, c

    cur = st_framecurrent()
    st_framecurrent(omeframe)
    rep = st_data(., "rep")
    b1  = (b1v == "" ? J(rows(rep), 1, 1) : st_data(., b1v))
    b0  = (b0v == "" ? J(rows(rep), 1, 0) : st_data(., b0v))
    st_framecurrent(cur)

    o = selectindex(rep :== 0)
    d = selectindex(rep :>  0)
    B = rows(d)
    if (B < 2) _error("ds_fb(): need at least 2 bootstrap draws")
    d0 = b0[d]
    d1 = b1[d]
    if (rows(o) > 0) {
        o0 = b0[o[1]]
        o1 = b1[o[1]]
    }
    else {
        o0 = mean(d0)
        o1 = mean(d1)
    }

    x    = rangen(xmin, xmax, np)
    F    = d0' :+ x * d1'                       // np x B : one column per draw
    fhat = o0  :+ x * o1                        // np x 1 : the plotted line
    fbar = rowsum(F) / B
    se   = sqrt(rowsum((F :- fbar):^2) / (B - 1))

    a = (1 - level/100) / 2

        lo = J(np, 1, .)
        hi = J(np, 1, .)
        for (i = 1; i <= np; i++) {
            s = sort(F[i,.]', 1)
            k = ceil(a * B)
            if (k < 1) k = 1
            if (k > B) k = B
            lo[i] = s[k]
            k = ceil((1 - a) * B)
            if (k < 1) k = 1
            if (k > B) k = B
            hi[i] = s[k]
        }
        st_numscalar("__fb_c", .)
    
    st_matrix("__fb", (x, fhat, se, lo, hi))
}
end

capture program drop ds_fitpoints
program define ds_fitpoints, rclass
	* Rebuild the (YC, YT) pre-period year cells that the first-step adjustment
	* is fitted on, from the estimation sample currently in memory, and park
	* them in a frame. Only needed to draw the band over the actual data points
	* and to pick the x-range -- the band itself needs only the -_ome- frame.
	* Expects in memory: wage_h year TREAT TP (as built in the state loop).
	syntax , [SAVEframe(name)]

	if "`saveframe'" == "" local saveframe fitpoints
	
	preserve

	capture drop YT YC yfirst X
	qui gen YT = meanwage*TREAT
	qui replace YT = . if TREAT==0
	qui gen YC = meanwage*(TREAT==0)
	qui replace YC = . if TREAT==1
	keep if year<TP
	collapse YT YC, by(year)
	tempfile ptf
	qui save "`ptf'" 
	
	restore

	capture frame drop `saveframe'
	frame create `saveframe'
	frame `saveframe' {
        qui use "`ptf'", clear
        qui count
        local n = r(N)
        qui summarize YC, meanonly
        return scalar xmin = r(min)
        return scalar xmax = r(max)
        di as txt "  `n' pre-period cells in frame -`saveframe'-" ///
	"  (YC range " as res %6.3f r(min) as txt " to " as res %6.3f r(max) as txt ")"
    }
end

capture program drop ds_fitband
program define ds_fitband, rclass
    * Confidence band around the first-step adjustment line YT = ome_0 + ome_1*YC,
    * built from the bootstrap draws of the adjustment coefficients sitting in
    * the -`resultsframe'_ome- frame written by ds_bootstrap.
    *
    * Default band is POINTWISE percentile: at each x, the (level)% percentile
    * interval of the bootstraps.  -restricted- bands the nocons fit (ome_1_res, intercept 0) instead;
    * -parallel- bands the mirror-image fit, intercept ome_0_res with the slope
    * held at 1, so the fitted line stays parallel to the 45-degree line.
    *
    * The dashed 45-degree line is the null under no selection bias.
    syntax , OMEframe(name) ///
        [XMIN(string) XMAX(string) NPoints(integer 200) LEVEL(real 95) ///
         RESTricted PARallel SAVEframe(name) POINTSframe(name) ///
         Title(string) YTITle(string) XTITle(string) ///
         Name(string) IDline NODRAW]

    if "`saveframe'" == "" local saveframe fitband
    if "`name'"      == "" local name fitband

    if "`restricted'" != "" & "`parallel'" != "" {
        di as err "specify only one of -restricted- and -parallel-"
        exit 198
    }

    if "`parallel'" != "" {
        * intercept-only fit: slope pinned at 1 (b1v empty), intercept ome_0_res
        local b0v ome_0_res
        local b1v ""
        local flab "parallel (slope fixed at 1)"
    }
    else if "`restricted'" != "" {
        local b0v ""
        local b1v ome_1_res
        local flab "restricted (nocons)"
    }
    else {
        local b0v ome_0
        local b1v ome_1
        local flab "unrestricted"
    }

    * fail if the draw variable is not in the frame
    foreach v in `b0v' `b1v' {
        frame `omeframe' {
            capture confirm variable `v'
            if _rc {
                di as err "variable -`v'- not found in frame -`omeframe'-"
                exit 111
            }
        }
    }

    * x-range: from the fitted data points unless given explicitly
    if "`xmin'" != "" confirm number `xmin'
    if "`xmax'" != "" confirm number `xmax'
    if "`xmin'" == "" | "`xmax'" == "" {
        if "`pointsframe'" == "" {
            di as err "specify xmin() and xmax(), or pointsframe() to read them off the data"
            exit 198
        }
        frame `pointsframe' {
            qui summarize YC, meanonly
            if "`xmin'" == "" local xmin = r(min)
            if "`xmax'" == "" local xmax = r(max)
        }
    }

    mata: ds_fb("`omeframe'", "`b0v'", "`b1v'", `xmin', `xmax', ///
                `npoints', `level')
    matrix colnames __fb = x fit se lo hi

    capture frame drop `saveframe'
    frame create `saveframe'
    frame `saveframe' {
        qui svmat double __fb, names(col)
        label var fit "fitted YT"
        label var se  "bootstrap SE of fitted value"
        label var lo  "lower band"
        label var hi  "upper band"

        * carry the data points into the same frame so twoway can overlay them
        if "`pointsframe'" != "" {
            frame `pointsframe' {
                tempfile ptf
                qui save "`ptf'"
            }
            qui merge 1:1 _n using "`ptf'", nogenerate
        }
    }

    local btype "pointwise percentile"
    di as txt _n "Adjustment-line band (`flab', `level'%, `btype')"
    di as txt "  frame -`saveframe'-, `npoints' grid points over YC in [" ///
        as res %6.3f `xmin' as txt ", " as res %6.3f `xmax' as txt "]"

    return scalar xmin  = `xmin'
    return scalar xmax  = `xmax'
    return scalar level = `level'
    return scalar c     = __fb_c
    return local  frame "`saveframe'"

    if "`nodraw'" != "" exit

    if `"`title'"'  == "" local title  "First-step adjustment (pre-period cells)"
    if `"`ytitle'"' == "" local ytitle "Treated group mean: California"
    if `"`xtitle'"' == "" local xtitle "Control group mean: `title'"

    * plots are assembled in order so the legend keys track which ones are drawn
    local k = 1
    local plotcmd `"(rarea lo hi x, color(navy%20) lwidth(none))"'
    local legord  `"1 "`level'% band""'

    * the 45-degree line is H0: (ome_0, ome_1) = (0, 1)
    if "`idline'" != "" {
        local ++k
        local plotcmd `"`plotcmd' (function y = x, range(`xmin' `xmax') lcolor(gs9) lpattern(dash))"'
        local legord  `"`legord' `k' "45-degree""'
    }

    local ++k
    local plotcmd `"`plotcmd' (line fit x, lcolor(navy) lwidth(medthick))"'
    local legord  `"`legord' `k' "fitted line""'

    if "`pointsframe'" != "" {
        local ++k
        local plotcmd `"`plotcmd' (scatter YT YC, mcolor(cranberry) msymbol(O) msize(medium))"'
        local legord  `"`legord' `k' "pre-policy observations""'
    }

    frame `saveframe' {
        twoway `plotcmd' ///
            , xtitle(`"`xtitle'"') ytitle(`"`ytitle'"') /*title(`"`title'"')*/ ///
              legend(order(`legord') rows(1) position(6) size(small)) ///
              name(`name', replace)
    }
end

capture program drop ds_eventstudy_plots
program define ds_eventstudy_plots
    * markers are the original-sample coefficients (b_orig) and the whiskers are bootstrap
    * percentile CIs (b_lo, b_hi). Outcomes are dodged horizontally at each year 
    syntax , SUMframe(name) OUTcomes(string) BASEyear(integer) ///
        [REFline(string) REFline2(string) Title(string asis) Name(string) ///
         ytop(string) ybot(string) LABels(string asis) SPREAD(real 0.18) ///
         YTITle(string asis) USEMEAN HOLLOWyears(numlist)]

    local J : word count `outcomes'

    * point estimate: original sample by default, bootstrap mean with -usemean-
    if "`usemean'" != "" local bvar b_mean
    else                 local bvar b_orig

    frame `sumframe' {
        qui levelsof yr, local(yearlist)
    }
    local nyears : word count `yearlist'

    tempname M
    local ncols = 4*`J'
    matrix `M' = J(`nyears', `ncols', .)

    * --- pull (coef, lo, hi) for each outcome x year out of the summary frame ---
    frame `sumframe' {
        local j = 0
        foreach o of local outcomes {
            local ++j
            local c1 = 4*`j' - 3
            local c2 = 4*`j' - 2
            local c3 = 4*`j' - 1
            local c4 = 4*`j'
            local off = (`j' - (`J'+1)/2) * `spread'

            local i = 0
            foreach y of local yearlist {
                local ++i
                matrix `M'[`i', `c1'] = `i' + `off'

                qui count if outcome=="`o'" & yr==`y'
                if r(N) == 0 continue

                qui summarize `bvar' if outcome=="`o'" & yr==`y', meanonly
                matrix `M'[`i', `c2'] = r(mean)
                qui summarize b_lo if outcome=="`o'" & yr==`y', meanonly
                matrix `M'[`i', `c3'] = r(mean)
                qui summarize b_hi if outcome=="`o'" & yr==`y', meanonly
                matrix `M'[`i', `c4'] = r(mean)
            }
        }
    }

    * --- x-axis labels / reference line ---
    local pos = 0
    local poslabels ""
    local refpos = .
    foreach y of local yearlist {
        local ++pos
        local poslabels `poslabels' `pos' "`y'"
        if "`refline'" != "" & `y' == `refline' local refpos = `pos'
	if "`refline2'" != "" & `y' == `refline2' local refpos2 = `pos'
    }
    if `refpos' < . local reflineopt "xline(`refpos', lcolor(red) lpattern(dash))"
    if `refpos2' < . local reflineopt2 "xline(`refpos2', lcolor(red) lpattern(dash))"
    else local reflineopt ""

    if `"`title'"' == "" local title "Event Study (bootstrap CIs)"
    if "`name'" == "" local name es_bs_overlay
    if `"`ytitle'"' == "" local ytitle "Effect relative to `baseyear'"

    if "`ybot'" != "" {
        local steps = (`ytop'-`ybot')/6
        local yrange "ylabel(`ybot'(`steps')`ytop', format(%5.2f)) yscale(range(`ybot' `ytop'))"
    }
    else local yrange ""

    * --- build the twoway figure command ---
    local colors `" "cranberry" "black" "navy" "dkgreen" "'
    local syms   O D T S

    local plotcmd ""
    local legord  ""
    local leglab  ""
    local labrest `"`labels'"'
    local j = 0
    foreach o of local outcomes {
        local ++j
        local c1 = 4*`j' - 3
        local c2 = 4*`j' - 2
        local c3 = 4*`j' - 1
        local c4 = 4*`j'
        local col : word `j' of `colors'
        local sym : word `j' of `syms'

        gettoken lab labrest : labrest
        local lab : subinstr local lab `"""' "", all
        local lab = strtrim(`"`lab'"')
        if `"`lab'"' == "" local lab "`o'"

        local plotcmd `"`plotcmd' (rcap v`c3' v`c4' v`c1', lcolor(`col') lwidth(medthin))"'
        local plotcmd `"`plotcmd' (scatter v`c2' v`c1', mcolor(`col') msymbol(`sym') msize(medium))"'

        local scatnum = 2*`j'
        local legord `"`legord' `scatnum'"'
        local leglab `"`leglab' label(`scatnum' "`lab'")"'
    }

    * --- optional -hollowyears()-: for the listed years, redraw each outcome's
    *     marker as a white-filled symbol with a coloured rim, on top of the
    *     solid one, so it reads as hollow. Rows of the plot frame are in
    *     -yearlist- order, so years are mapped to row numbers and selected
    *     with inlist(_n, ...). Appended after the main loop, so the legend
    *     plot numbers (2*j) are unaffected. ---
    if "`hollowyears'" != "" {
        local hpos ""
        local i = 0
        foreach y of local yearlist {
            local ++i
            local hit : list y in hollowyears
            if `hit' local hpos "`hpos', `i'"
        }
        if "`hpos'" != "" {
            local j = 0
            foreach o of local outcomes {
                local ++j
                local c1 = 4*`j' - 3
                local c2 = 4*`j' - 2
                local col : word `j' of `colors'
                local sym : word `j' of `syms'
                local plotcmd `"`plotcmd' (scatter v`c2' v`c1' if inlist(_n`hpos'), mfcolor(white) mlcolor(`col') msymbol(`sym') msize(medium))"'
            }
        }
    }

    tempname pfr
    capture frame drop `pfr'
    frame create `pfr'
    frame `pfr' {
        qui svmat double `M', names(v)
        twoway `plotcmd' ///
            , xlabel(`poslabels', angle(45)) ///
              yline(0, lcolor(black) lpattern(dash)) ///
              `reflineopt' `reflineopt2' ///
              xtitle("Year") ///
              ytitle(`"`ytitle'"') ///
              title(`"Control group: `title'"') ///
              `yrange' ///
              legend(order(`legord') `leglab' rows(1) position(6) size(small)) ///
              name(`name', replace)
    }
    frame drop `pfr'
end

********************************************************************************
******************************************

* %%%%%%%%%%%%%  
* PLOT FIGURES OF BOOTSTRAPPED RESULTS
* %%%%%%%%%%%%%  


foreach state of global states {
	frame reset
	use "output/mean_ts.dta", replace
	keep if statefip == 6 | statefip == `state'
	local statename : label (statefip) `state'

	sum MIN_CAL_YEAR if statefip==`state', meanonly
	local polyearc = r(mean)
	gen TP = 1988
	gen TREAT = statefip == 6
	
	frame create bs_es_`state'
	frame bs_es_`state': use "output/bs_states/bs_es_`state'.dta"

	frame create bs_es_`state'_ome
	frame bs_es_`state'_ome: use "output/bs_states/bs_ome_`state'.dta"
	
	frame create bs_sum_`state'
	frame bs_sum_`state': use "output/bs_states/bs_sum_`state'.dta"

    * --------------------------------------------------------------------------
	* STEP 1: OMEGA

	ds_fitpoints, saveframe(fitpts_`state')
	ds_fitband, omeframe(bs_es_`state'_ome) pointsframe(fitpts_`state') ///
	level(95) saveframe(fitband_`state') name(fitband_`state') ///
	title(`statename') idline 
	    graph export output/figures/STEP1_State_`state'.eps, replace
	ds_fitband, omeframe(bs_es_`state'_ome) pointsframe(fitpts_`state') ///
	level(95) saveframe(fitband_`state') name(fitband_`state') ///
	title(`statename') idline restricted
	    graph export output/figures/STEP1_restricted_State_`state'.eps, replace
	ds_fitband, omeframe(bs_es_`state'_ome) pointsframe(fitpts_`state') ///
	level(95) saveframe(fitband_`state') name(fitband_`state') ///
	title(`statename') idline parallel
	    graph export output/figures/STEP1_parallel_State_`state'.eps, replace

     * --------------------------------------------------------------------------
	* STEP 2: EVENT STUDY PLOT with bootstrap CIs (same level as specified above)
	ds_eventstudy_plots, sumframe(bs_sum_`state') ///
	outcomes(wage_tilde wage_h wage_tilde_ln) baseyear(1987) ///
	refline("1988") refline2("`polyearc'") title(`statename') ///
	labels("Double Selection" "Single Selection: Levels" "Single Selection: Proportional") ///
	name(es_bs_overlay_`state') hollowyears(1988 `polyearc'/1991)
	graph export output/figures/ES_BS_State_`state'.eps, replace
	
		
*

	graph close _all


} //state

